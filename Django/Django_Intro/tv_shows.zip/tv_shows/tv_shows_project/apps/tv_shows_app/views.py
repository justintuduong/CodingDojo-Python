from __future__ import unicode_literals
from django.shortcuts import render, redirect, HttpResponse
from .models import *
from datetime import datetime
from django.contrib import messages


# -----------------------------------------------------------
# GET data, render root page
# -----------------------------------------------------------

def index(request):
    context = {
        "show_list": Show.objects.all()
    }
    return render(request, "index.html", context)

# -----------------------------------------------------------
# POST form, RENDER new show
# -----------------------------------------------------------


def add_show(request):
    return render(request, "new_show.html")

# -----------------------------------------------------------
# POST data, REDIRECT to show_desc.
# -----------------------------------------------------------


def process_add_show(request):
    errors = Show.objects.basic_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value, extra_tags=key)
        return redirect('/show/add')

    if request.method == "POST":
        title = request.POST["title"]
        network = request.POST["network"]
        release_date = request.POST["release_date"]
        description = request.POST["description"]
        show = Show.objects.create(
            title=title, network=network, release_date=release_date, description=description)
        show_id = str(show.id)
    return redirect("/show/description/"+show_id)

# -----------------------------------------------------------
# GET data, RENDER show list
# -----------------------------------------------------------


def show_description(request, show_id):
    context = {
        "show": Show.objects.get(id=show_id)
    }

    return render(request, "show_description.html", context)

# -----------------------------------------------------------
# RENDER EDIT PAGE
# -----------------------------------------------------------


def edit_show(request, show_id): 
    show = Show.objects.get(id=show_id)
    date = show.release_date.strftime("%Y-%m-%d")
    print(date)
    context = {
        "show": show,
        "date": date
    }
    return render(request, "edit_show.html", context)

# -----------------------------------------------------------
# POST redirect to EDIT PAGE
# -----------------------------------------------------------

def edit_show_process(request):
    errors = Show.objects.basic_validator(request.POST)
    if len(errors) > 0:
        for key, value in errors.items():
            messages.error(request, value, extra_tags=key)
        return redirect('/show/add')
        
    if request.method == "POST":
        show_id = request.POST["id"]
        title = request.POST["title"]
        network = request.POST["network"]
        release_date = request.POST["release_date"]
        description = request.POST["description"]
    show_to_update = Show.objects.get(id=show_id)
    show_to_update.title = title
    show_to_update.network = network
    show_to_update.release_date = release_date
    show_to_update.description = description
    show_to_update.save()
    show_id = str(show_id)
    return redirect("/show/description/"+ str(show_id))
    "/show/description/"+show_id

# -----------------------------------------------------------
# DELETE, REDIRECT
# -----------------------------------------------------------

def delete_show(request, show_id):
    remove_show = Show.objects.get(id=show_id)
    remove_show.delete()
    return redirect ('/')


