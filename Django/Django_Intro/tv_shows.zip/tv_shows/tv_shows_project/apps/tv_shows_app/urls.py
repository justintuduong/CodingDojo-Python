from django.conf.urls import url
from . import views
                    
urlpatterns = [
    url(r'^$', views.index), 
    url(r'^show/add$', views.add_show), #POST form, ADD NEW SHOW
    url(r'^show/add/process$', views.process_add_show), #PROCESS POST, redirect
    url(r'^show/description/(?P<show_id>\d+)$', views.show_description), #render
    url(r'^show/edit/(?P<show_id>\d+)$', views.edit_show),
    url(r'^show/edit/process$', views.edit_show_process),
    url(r'^show/delete/(?P<show_id>\d+)', views.delete_show),
]

# (?P<show_id>\d+)