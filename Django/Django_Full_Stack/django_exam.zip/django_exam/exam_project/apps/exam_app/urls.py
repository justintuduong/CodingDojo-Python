from django.conf.urls import url
from . import views

urlpatterns = [
    url(r'^$', views.index),
    url(r'^user/registration$', views.process_registration),
    url(r'^user/login$', views.process_login),
    url(r'^user/homepage$', views.home_page),
    url(r'^user/logout$', views.logout),
    # --------------------------------------------------------------------------------------------------------------------
    url(r'^wishes/new$', views.new_wish), #need jinja id later
    url(r'^wishes/new/process$', views.new_wish_process),
    url(r'^wishes/edit/(?P<gift_id>\d+)$', views.edit_wish),
    url(r'^wishes/edit/process$', views.edit_wish_process),
    url(r'^wishes/granted/(?P<gift_id>\d+)$', views.granted),
    url(r'^wishes/delete/(?P<gift_id>\d+)$', views.delete_gift),



]
#  url(r'^books/favorite/(?P<bookid>\d+)$', views.like_book),