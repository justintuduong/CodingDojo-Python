from django.db import models
import re
import bcrypt
EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')

class UserManager(models.Manager):
    def reg_validator(self, postData):
        errors = {}
        if len(postData['first_name']) < 2:
            errors["first_name"] = "First name should be at least 2 characters"
        if len(postData['last_name']) < 2:
            errors["last_name"] = "Last name should be at least 2 characters"
        if not EMAIL_REGEX.match(postData["email"]) :
            errors["email"] = "Invalid email address"
        if len(postData["password"]) < 8:
            errors["password"] = "Password must have at least 8 characters"
        if postData["password"] != postData["password_confirm"]:
            errors["password_confirm"] = "Password does not match"
        return errors
    
    def log_validator(self, postData):
        errors = {}
        user_credentials = User.objects.filter(email=postData["email"])
        if len(user_credentials) < 1:
            errors["login_credentials"] = "Invalid login credentials "
        for email in user_credentials:
            if not bcrypt.checkpw(postData["password"].encode(), email.password.encode()):
                errors["login_credentials"] = "Invalid login credentials"
        return errors

    def wish_validator(self, postData):
        errors = {}
        if len(postData['gift_name']) < 3:
            errors["gift_name"] = "Wish should be at least 3 characters"
        if len(postData['description']) < 3:
            errors["description"] = "Description should be at least 3 characters"
        return errors


class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    birthday = models.CharField(max_length=255)
    password = models.CharField(max_length=50)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()


class Gift(models.Model):
    gift_name = models.CharField(max_length=255)
    gift_description = models.CharField(max_length=255)
    granted = models.ForeignKey(User, related_name="wisher")
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()
