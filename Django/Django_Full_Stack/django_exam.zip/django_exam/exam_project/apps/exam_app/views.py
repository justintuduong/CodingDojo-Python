from __future__ import unicode_literals
from django.shortcuts import render, redirect, HttpResponse
from .models import *
from datetime import datetime
from django.contrib import messages
import bcrypt


def index(request):
    return render(request, "exam_app/index.html")

def process_registration(request):
    if request.method == "POST":
        errors = User.objects.reg_validator(request.POST)
        for key, value in errors.items():
            messages.error(request, value, extra_tags=key)
        print(errors)
    if len(errors) > 0:
        return redirect('/')
    else:
        pw_hash = bcrypt.hashpw(
            request.POST["password"].encode(), bcrypt.gensalt()).decode()
        print(pw_hash)
        new_user = User.objects.create(
            first_name=request.POST["first_name"], last_name=request.POST["last_name"], email=request.POST["email"], password=pw_hash)
        request.session['id'] = new_user.id
        print(request.session['id'])
        request.session['active'] = True
        return redirect("/user/homepage")

def process_login(request):
    if request.method == "POST":
        errors = User.objects.log_validator(request.POST)
        for key, value in errors.items():
            messages.error(request, value, extra_tags=key)
            print(errors)
    if len(errors) > 0:
        return redirect('/')

    else:
        user = User.objects.get(email=request.POST["email"])
        request.session['id'] = user.id
        request.session['active'] = True
        print(request.session['id'])
        return redirect("/user/homepage")


def home_page(request):  # wish list page, shows all items + granted wishes
    if request.session['active'] == False:
        return redirect('/')
    
    context = {
        "user": User.objects.get(id=request.session['id']),
        "list": Gift.objects.all(),
        "gift_list": User.objects.get(id=request.session['id']).wisher.all(),

    }
    return render(request, "exam_app/home_page.html", context)


def logout(request):

    request.session.clear()
    request.session['active'] = False
    if "id" in request.session:
        print("YOU'LL NEVER FORGET ME BWAHAHA!")
    else:
        print("YOU FORGOT ME YOU ASSHOE!")

    return redirect('/')


# -------------------------------------------------------------------------------------------------------------------------------------------------

def new_wish(request):
    return render(request, "exam_app/makeawish.html")


def new_wish_process(request):
    if request.method == "POST":
        errors = Gift.objects.wish_validator(request.POST)
        for key, value in errors.items():
            messages.error(request, value, extra_tags=key)
        print(errors)
    if len(errors) > 0:
        return redirect('/wishes/new')

    if request.method == "POST":
        user = User.objects.get(id=request.session['id'])
        gift = request.POST['gift_name']
        gift_description = request.POST['description']
        gift = Gift.objects.create(gift_name=gift, gift_description=gift_description, granted=user)
    return redirect("/user/homepage")


def edit_wish(request, gift_id):
    context = {
        "gift": Gift.objects.get(id=gift_id)
    }
    print(context)
    return render(request, "exam_app/editwishes.html", context)


def edit_wish_process(request):
    if request.method == "POST":
        errors = Gift.objects.wish_validator(request.POST)
        for key, value in errors.items():
            messages.error(request, value, extra_tags=key)

    if len(errors) > 0:
        return redirect('/wishes/new')

    else:
        gift_to_update = Gift.objects.get(id=request.POST['gift_id'])                          
        new_gift_name = request.POST['gift_name']                         
        new_description = request.POST['description']                 
        gift_to_update.gift_name = new_gift_name        
        gift_to_update.gift_description = new_description
        gift_to_update.save()   
    return redirect("/user/homepage")

def delete_gift(request, gift_id):
    remove_gift = Gift.objects.get(id=gift_id)
    remove_gift.delete()
    return redirect ('/user/homepage')

def granted(request, gift_id):
    gift = Gift.objects.get(id=gift_id)
    user = User.objects.get(id=request.session['id'])
    gift.granted.add(user)
    return redirect('/user/homepage')
