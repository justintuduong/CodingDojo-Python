from django.db import models
import re
import bcrypt


class UserManager(models.Manager):
    def reg_validator(self, postData):
        errors = {}
        if len(postData['first_name']) < 2:
            errors['first_name'] = "Invalid First Name! - Must be 2 characters long"
        if not (postData['first_name'].isalpha()) == True:
            errors['first_name'] = "Invalid First Name! - Can only contain alphabetic characters"
        if len(postData['last_name']) < 2:
            errors['last_name'] = "Invalid Last Name! - Must be 2 characters long"
        if not (postData['last_name'].isalpha()) == True:
            errors['last_name'] = "Invalid Last Name! - Can only contain alphabetic characters"
        EMAIL_REGEX = re.compile(r'^[a-zA-Z0-9.+_-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]+$')
        if not EMAIL_REGEX.match(postData['email']):
            errors['email'] = "Invalid Email Address!"
        emailAlreadyExists = User.objects.filter(email=postData['email']).exists()
        if (emailAlreadyExists):
            errors['email'] = "Email already in system"
        if len(postData['password']) < 8:
            errors['password'] = "Password must be at least 8 characters long"
        if postData['password'] != postData['pwconfirm']:
            errors['confirm_pw'] = "Password and Confirm Password must match"
        return errors

    def log_validator(self, postData):
        errors = {}
        user_credentials = User.objects.filter(email=postData["email"])
        if len(user_credentials) < 1:
            errors["login_credentials"] = "Invalid login credentials "
        for email in user_credentials:
            if not bcrypt.checkpw(postData["password"].encode(), email.password.encode()):
                errors["login_credentials"] = "Invalid login credentials"
        return errors

class User(models.Model):
    first_name = models.CharField(max_length=255)
    last_name = models.CharField(max_length=255)
    email = models.CharField(max_length=255)
    password = models.CharField(max_length=255)
    created_at = models.DateTimeField(auto_now_add=True)
    updated_at = models.DateTimeField(auto_now=True)
    objects = UserManager()
    def __repr__(self):
        return f"<User object: {self.first_name} {self.last_name} {self.email} {self.password} ({self.id})>"

class TripManager(models.Manager):
    def add_validator(self, postData):
        errors = {}
        if len(postData['destination']) < 3:
            errors['destination'] = "A trip must consist of at least 3 characters!"
        if len(postData['start_date']) < 1:
            errors['start_date'] = "invalid date"
        if len(postData['start_date']) < 1:
            errors['end_date'] = "invalid date"
        if len(postData['plan']) < 3:
            errors['plan'] = "A plan must be provided, at least 3 characters!"
        return errors
    def edit_validator(self, postData):
        errors = {}
        if len(postData['destination']) < 3:
            errors['destination'] = "A trip must consist of at least 3 characters!"
        if len(postData['start_date']) < 1:
            errors['start_date'] = "invalid date"
        if len(postData['start_date']) < 1:
            errors['end_date'] = "invalid date"
        if len(postData['plan']) < 3:
            errors['plan'] = "A plan must be provided, at least 3 characters!"
        return errors

class Trip(models.Model):
    destination = models.CharField(max_length=255)
    start_date = models.DateField()
    end_date = models.DateField()
    plan = models.TextField()
    joined = models.BooleanField( default = False)
    created_by = models.ForeignKey(User, related_name="user_trips")
    created_at = models.DateField(auto_now_add=True)
    updated_at = models.DateField(auto_now=True)
    objects = TripManager()