from django.apps import AppConfig


class ExamApp2Config(AppConfig):
    name = 'exam_app_2'
