from django.shortcuts import render, HttpResponse, redirect
from .models import *
from django.contrib import *
import bcrypt
import datetime
import re




# ------------------------------------------------------------------------------------------------
# Login and registration
# ------------------------------------------------------------------------------------------------


def index(request):
    return render(request, 'exam_app_2/index.html')


# -------------------------
# Registration
# -------------------------
def process_registration(request):
    if request.method == "POST":
        errors = User.objects.reg_validator(request.POST)
        for key, value in errors.items():
            messages.error(request, value, extra_tags=key)
        print(errors)
    if len(errors) > 0:
        return redirect('/')
    else:
        pw_hash = bcrypt.hashpw(request.POST["password"].encode(), bcrypt.gensalt()).decode()
        print(pw_hash)
        user = User.objects.create(first_name=request.POST["first_name"], last_name=request.POST["last_name"], email=request.POST["email"], password=pw_hash)
        request.session['id'] = user.id
        print(request.session['id'])
        request.session['active'] = True

        return redirect("/dashboard")


def process_login(request):
    if request.method == "POST":
        errors = User.objects.log_validator(request.POST)
        for key, value in errors.items():
            messages.error(request, value, extra_tags=key)
            print(errors)
    if len(errors) > 0:
        return redirect('/')

    else:
        request.method == "POST"
        user = User.objects.get(email=request.POST["email"])
        request.session['id'] = user.id
        request.session['active'] = True
        print(request.session['id'])
        print(f" SESSION ACTIVITY IS NOW {request.session['active']} ")
        print("I AM WORKING!")
        return redirect("/dashboard")


def dashboard (request):
    print(request.session['id'])
    context = {
        'list': Trip.objects.filter(created_by = request.session['id'], joined = False),
        'joined': Trip.objects.filter(joined = True),
        'user': User.objects.get(id=request.session['id']),
        'all_trips' : Trip.objects.all(),
    }
    return render(request, "exam_app_2/dashboard.html",context)

def add_plan (request):
    print(request.session['id'])
    return render(request, "exam_app_2/add_plan.html")

def add_plan_process(request):

    if request.method == "POST":
        errors = Trip.objects.add_validator(request.POST)
        for key, value in errors.items():
            messages.error(request, value, extra_tags = key)
        if len(errors) > 0:
            return redirect('/plan/add')

        else:
            destination = request.POST['destination']
            start_date = request.POST['start_date']
            end_date= request.POST['end_date']
            plan = request.POST['plan']
            planned_by_id = request.session['id']

            created_by = User.objects.get(id=planned_by_id)
            new_trip = Trip.objects.create(destination = destination, start_date = start_date, end_date = end_date, plan= plan, created_by = created_by)

    return redirect("/dashboard")


def edit_plan (request, trip_id):
    context = {
        "trip": Trip.objects.get(id=trip_id)
    }
    print(context)
    return render(request, "exam_app_2/edit_plan.html", context)

def edit_plan_process (request):
    trip_id = request.POST['trip_id']
    if request.method == "POST":
        errors = Trip.objects.edit_validator(request.POST)
        for key, value in errors.items():
            messages.error(request, value, extra_tags=key)

    if len(errors) > 0:
        print(trip_id)
        return redirect('/plan/edit/'+ str(trip_id))

    else:
        trip_to_update = Trip.objects.get(id=request.POST['trip_id'])                          
        destination = request.POST['destination']                         
        start_date = request.POST['start_date'] 
        end_date = request.POST['end_date']
        plan = request.POST['plan']
        trip_to_update.destination = destination
        trip_to_update.start_date = start_date
        trip_to_update.end_date = end_date
        trip_to_update.plan = plan
        trip_to_update.save()
    return redirect("/dashboard")


def remove_plan(request, trip_id):
    remove_trip = Trip.objects.get(id=trip_id)
    remove_trip.delete()
    return redirect('/dashboard')

def show_plan(request, trip_id):
    context = {
        "trip" : Trip.objects.get(id=trip_id),
    }
    return render (request, "exam_app_2/show_plan.html",context)


# ------------------------------------------------------------------------------------------------
# Logout
# ------------------------------------------------------------------------------------------------

def logout(request):
    request.session.clear()
    request.session['active'] = False
    return redirect('/')