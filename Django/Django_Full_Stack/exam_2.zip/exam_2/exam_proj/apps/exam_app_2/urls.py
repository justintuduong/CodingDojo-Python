from django.conf.urls import url
from . import views
                    
urlpatterns = [
    url(r'^$', views.index),
    url(r'^registration/process$', views.process_registration),
    url(r'^login/process', views.process_login),
    url(r'^dashboard$', views.dashboard),
    url(r'^plan/add$', views.add_plan),
    url(r'^plan/add/process$', views.add_plan_process),
    url(r'^plan/delete/(?P<trip_id>\d+)', views.remove_plan),
    url(r'^plan/edit/(?P<trip_id>\d+)', views.edit_plan),
    url(r'^plan/edit/process', views.edit_plan_process),
    url(r'^show/plan/(?P<trip_id>\d+)', views.show_plan),


    url(r'^logout$', views.logout)
]